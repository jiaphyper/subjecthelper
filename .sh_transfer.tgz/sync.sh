#!/bin/sh
cd "$(dirname "$0")" && rsync -a --delete --exclude node_modules --exclude .next --exclude data --exclude '*.log' --exclude next-env.d.ts --exclude sync.sh --exclude tsconfig.tsbuildinfo --exclude '*.tmp.*' ./ $HOME/mnt/subjecthelper/
